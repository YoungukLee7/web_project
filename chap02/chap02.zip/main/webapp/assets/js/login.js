const btn = document.getElementById('btn-logout');

btn.addEventListener('click',() => {
	location.href="/chap02/attrebute/logout";
})